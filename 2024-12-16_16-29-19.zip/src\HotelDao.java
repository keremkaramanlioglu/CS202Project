public class HotelDao {
    DBConnectionControl dbConnectionControl;
}
